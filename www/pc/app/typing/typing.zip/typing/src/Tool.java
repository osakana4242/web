import java.awt.Graphics ;

public class Tool
{
	//****** 2�����̓����蔻���Ԃ�
	public static boolean hitJudge2D( int x1 , int y1 , int w1 , int h1 , int x2 , int y2 , int w2 , int h2 )
		{
		if ( !hitJudge1D( x1 , w1 >> 1 , x2 , w2 >> 1 ) ) return false ;
		if ( !hitJudge1D( y1 , h1 >> 1 , y2 , h2 >> 1 ) ) return false ;
		return true ;
		}
	//****** 1�����̓����蔻���Ԃ� ********
	public static boolean hitJudge1D( int p1 , int b1 , int p2 , int b2 )
		{
		if ( p1 + b1 >= p2 + b2 )
			{
			if ( ( p1 + b1 ) - ( p2 + b2 ) <= ( b1 * 2 ) ) return true ;
			return false ;
			}
		else if ( ( p2 + b2 ) - ( p1 + b1 ) <= ( b2 * 2 ) ) return true ;
		return false ;
		}
		
	//****** �t�H���g�̍�����Ԃ� ********
	public static int getFontHeight( Graphics g )
		{
		return g.getFontMetrics( g.getFont() ).getAscent() -
		       g.getFontMetrics( g.getFont() ).getDescent() +
		       g.getFontMetrics( g.getFont() ).getLeading() ;
		}
}
