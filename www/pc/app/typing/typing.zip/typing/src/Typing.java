import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Typing extends NeoFontDate implements Runnable
{
	static int style = 0;
	
	TextWindowA[] tw;
	
	Thread myThread;
	
	KeyJudge kj;
	Enemy ene;
	
	Image myImage[][];
	Image background[];
	
	
	CountDownTimer cdt;
	
	int goalPoint;//�v���C���[�������I���ʒu
	int startPoint; //�v���C���[�������n�߂�ʒu
	int sleepTime = 10;
	
	public Typing(Graphics ogr)
	{
		//����I�яo���A�p�ӁB
		SelectQ.select();
		
		startPoint = Date.appWidth / 20 - (Date.walkWidth / 2);
		goalPoint = (Date.appWidth / 20) * 19 - (Date.walkWidth / 2);
		
		kj = new KeyJudge(Date.appWidth/2,
							(Date.appHeight/7)*2);
		kj.runner.setMoveSpeed(10);
		
		ene = new Enemy(Date.appWidth/2,
							(Date.appHeight/7)*5);
		ene.tp.runner.setMoveSpeed(10);
		
		//�v���C���[������`�Ԃɐݒ�
		kj.runner.walkMode();
		//�G������`�Ԃɐݒ�
		ene.tp.runner.walkMode();
		//�v���C���[���X�^�[�g�n�_�ֈړ�
		kj.runner.startMove(startPoint,kj.runner.getAfterY());
		//�G���X�^�[�g�n�_�ֈړ�
		ene.tp.runner.startMove(startPoint,ene.tp.runner.getAfterY());
		
		//�J�E���g�_�E���^�C�}�[�̏����ݒ�
		cdt = new CountDownTimer(0,0);
		//�J�E���g�_�E���^�C�}�[���c��8�b�ɐݒ�
		cdt.setTime(0,0,0,8,0,0);
		//�J�E���g�_�E���̊J�n
		cdt.start();
		
		style = 0;
		kj.on_se = false;
		ene.tp.on_se = false;
		//Typing�Q�[���J�n
		start();
		
	}
	
	public void key(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_ESCAPE:
				allStop();
				style = 0;
				Main.style = 1;
				break;
			case KeyEvent.VK_ENTER:
			case KeyEvent.VK_SPACE:
				switch(style)
				{
					case 2:
					case 3:
						style = 4;
						break;
					case 4:
						allStop();
						style = 0;
						Main.style = 1;
						break;
					default:
						break;
				}
				break;
			default:
				break;
		}
		
		if(style == 1) kj.judge(e);
				
	}
	public void draw(Graphics ogr,ImageObserver ios)
	{
		switch(style)
		{
			case 0:
			case 1:
			case 2:
			case 3:
				ogr.setColor(Color.black);
				ogr.fillRect(0,0,Date.appWidth,Date.appHeight);
				ogr.drawImage(background[0],0,0,ios);
		
				kj.draw(ogr,ios);
				ene.draw(ogr,ios);
			
				ogr.setColor(Color.white);
			
				ogr.setFont(Date.xlFont);
				Place.setSize(Date.appWidth,Date.appHeight);
				Place.setPoint(0,0);
				Place.setCenterY( -(getFontHeight(ogr,Date.xlFont) / 2 ));
				String s = new String();
				Image _img = null;
				int _width = 0;
				int _height = 0;
				switch(style)
				{
					case 0:
						if(cdt.s[2] > 5)
						{
							_img = null;
						} else
						{
							if(cdt.s[2] > 0)
							{
								_img = myImage[0][cdt.s[2]-1];
								_width =  Date.countSize;
								_height = Date.countSize;
							}
							else			 
							{
								_img =    myImage[1][0];
								_width =  Date.startWidth;
								_height = Date.startHeight;
							}
						}
				
						break;
					case 1:
						_img = null;
					break;
					case 2:
						_img = myImage[2][0];
						_width = Date.winWidth;
						_height = Date.winHeight;
						break;
					case 3:
						_img = myImage[3][0];
						_width = Date.loseWidth;
						_height = Date.loseHeight;
						break;
					default:
						break;
				}
				ogr.drawImage(_img,
								(Date.appWidth  - _width)/2,
								(Date.appHeight - _height)/2,
								ios);
				break;
			case 4:
				ogr.setColor(Color.black);
				ogr.fillRect(0,0,Date.appWidth,Date.appHeight);
				
				ogr.setColor(Color.green);
				ogr.setFont(Date.sFont);
				ogr.drawString("���Ő��@�@�@�F" + String.valueOf(kj.type),20,20);
				ogr.drawString("���s�����Ő��F" + String.valueOf(kj.missType),20,40);
				ogr.drawString("�������@�@�@�F" + String.valueOf(kj.success),20,60);
				ogr.drawString("���_�@�@�@�@�F" + String.valueOf(kj.getScore()),20,80);
				
				break;
			default:
				break;
		}
	}
	
	public void allStop()
	{
		if(kj != null) {
			kj.allStop();
			kj = null;
		}
		
		if(ene != null) {
			ene.allStop();
			ene = null;
		}
		
		if (cdt != null ) {
			cdt.stop();
			cdt = null;
		}
		stop();
	}
	
	public void start()
	{
		if(myThread == null)
		{
			myThread = new Thread(this);
			myThread.start();
		}
	}
	
	public void run()
	{
		Thread thisThread = Thread.currentThread();
		while ( myThread == thisThread )
		{
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException e)
			{
				break;
			}
			
			switch(style)
			{
				case 0:
					if (cdt != null && cdt.countZero() )
					{
						style = 1;
						kj.on_se = true;
						ene.tp.on_se = true;
						kj.runner.runMode();
						ene.tp.runner.runMode();
						ene.start();
					} 					
					break;
				
				case 1:	
					if(kj != null && kj.runner.getX() >= goalPoint)
					{
						ene.stop();
						kj.runner.setMoveSpeed(10);
						kj.runner.startMove(Date.appWidth,kj.runner.getAfterY());
						ene.tp.cut.stop();
						ene.tp.runner.downMode();
						style = 2;
						kj.on_se = false;
						ene.tp.on_se = false;
					}
					else if(ene.tp.runner.getX() >= goalPoint)
					{
						ene.stop();
						ene.tp.runner.setMoveSpeed(10);
						ene.tp.runner.startMove(Date.appWidth,ene.tp.runner.getAfterY());
						kj.runner.downMode();
						ene.tp.cut.stop();
						kj.cut.stop();
						style = 3;
						kj.on_se = false;
						ene.tp.on_se = false;
					}
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					break;
				default:
					break;
			}
		}
	}
	
	public void stop()
	{
		myThread = null;
	}
}

	