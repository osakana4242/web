import java.awt.*;
import java.awt.image.*;

public class Runner03
{
	int mode = 0;
	
	public void draw(Graphics grf,ImageObserver o,int x,int y,int turn)
	{
		grf.drawImage(Runner00.myImage[mode][turn],x,y,o);
	}
}