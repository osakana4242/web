import java.awt.*;
import java.awt.image.*;

public class CountDownTimer implements Runnable
{
	Thread myThread;
	TextWindowA tw;
	final int sleepTime = 10;
	
	int[] s = new int[4];//second �b
	int[] m = new int[2];//minute ��
	
	Font font = Date.sFont;
	int fontSize = Date.sFontSize;
	int fontWidth = fontSize;
	
	private boolean countZero = true; 
	
	public CountDownTimer()
	{
		setTime(0,0,0,0,0,0);
		
		Place.setSize(Date.appWidth,Date.appHeight);
		Place.setPoint(0,0);
		
		tw = new TextWindowA(fontSize*9,fontSize + 10);
		
		Place.setCenterX( tw.width  / 2 );
		Place.setCenterY( tw.height / 2 );
		
		setPoint(0,0);
		
	}
	//�R���X�g���N�^
	public CountDownTimer(int pointX,int pointY)
	{
		setTime(0,0,0,0,0,0);
		
		Place.setSize(Date.appWidth,Date.appHeight);
		Place.setPoint(0,0);
		
		tw = new TextWindowA(fontSize*9,fontSize + 10);
		
		Place.setCenterX( tw.width  / 2 );
		Place.setCenterY( tw.height / 2 );
		
		setPoint(pointX,pointY);
		
	}
	
	//���v��\�����鎞�̈ʒu��ݒ�
	public void setPoint(int pointX,int pointY)
	{
		tw.setPoint(pointX,pointY);
	}
	
	//�J�E���g���h�R����n�߂邩��ݒ�
	public void setTime(int m1,int m0,int s3,int s2,int s1,int s0)
	{
		m[1] = m1;
		m[0] = m0;
		s[3] = s3;
		s[2] = s2;
		s[1] = s1;
		s[0] = s0;
	}
	
	//�J�E���g��0����true��Ԃ��B
	public boolean countZero()
	{
		return countZero;
	}
	
	//�J�E���g���J�n
	public void start()
	{
		if ( myThread == null )
		{
			countZero = false;
			myThread = new Thread(this);
			myThread.start();
		}
	}
	
	public void run()
	{
		Thread thisThread = Thread.currentThread();
		while ( myThread == thisThread )
		{
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException e)
			{
				break;
			}
			
			if ( (m[0] + m[1] +s[0] + s[1] + s[2] + s[3]) == 0  ) 
			{
				countZero = true;
				stop();
			}
			else
			{ 
			
				s[0]--;
				for ( int i = 0 ; i < s.length ; i++ )
				{
					if ( s[i] < 0 )
					{
						s[i] = 9;
						s[i+1]--;
					}
					else break;
				}
				
				if ( s[3] < 0 )
				{
					s[3] = 5;
					m[0]--;
					if ( m[0] < 0 )
					{
						m[0] = 9;
						m[1]--;
						if ( m[1] < 0 )
						{
							m[1] = 9;
						}
					}
				}
			}
		}
	}
	
	//�J�E���g���ꎞ��~
	public void stop()
	{
		myThread = null;
	}
	
	public void draw(Graphics ogr)
	{
		
		tw.draw(ogr);
		
		Place.setSize(tw.width,tw.height);
		Place.setPoint(tw.pointX,tw.pointY);
		Place.setCenterY( -(fontSize / 2 ) );
		Place.setCenterX( (fontWidth * 8) / 2 );
		
		ogr.setFont(font);
		ogr.setColor(Color.yellow);
		equalsWidth(ogr,String.valueOf(m[1]),0);
		equalsWidth(ogr,String.valueOf(m[0]),1);
		ogr.setColor(Color.white);
		equalsWidth2(ogr,":",				 2);
		ogr.setColor(Color.green);
		equalsWidth(ogr,String.valueOf(s[3]),3);
		equalsWidth(ogr,String.valueOf(s[2]),4);
		ogr.setColor(Color.white);
		equalsWidth2(ogr,":",				 5);
		ogr.setColor(Color.red);
		equalsWidth(ogr,String.valueOf(s[1]),6);
		equalsWidth(ogr,String.valueOf(s[0]),7);
		
	}
	public void equalsWidth(Graphics ogr,String str,int num)
	{
		
		ogr.drawString(str,
			(fontWidth -(ogr.getFontMetrics(font).stringWidth(str)))/2 +
				Place.xAlign(1,2) + (fontWidth * num),
			(Place.yAlign(1,2) ) ); 
		
	}
	public void equalsWidth2(Graphics ogr,String str,int num)
	{
		
		ogr.drawString(str,
			(fontWidth -(ogr.getFontMetrics(font).stringWidth(str)))/2 +
				Place.xAlign(1,2) + (fontWidth * num),
			(Place.yAlign(1,2) - ogr.getFontMetrics(font).getDescent() )); 
		
	}
}