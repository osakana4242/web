import java.awt.*;
import java.awt.image.*;

public class SelectQ extends NeoFontDate
{
	static String Q[][];
	
	
	
	String japa = new String();
	String rome = new String();
	
	int mojiCounter = 0;
	int QCounter = 0;
	
	final Font font = Date.mFont;
	int fontHeight;
	final int fontSize = Date.mFontSize;
	final int halfFontSize = (fontSize / 2) + 4;
	
	public SelectQ()
	{
		mojiCounter = 0;
		setQ();	
	}
	
	public static void select()
	{
		switch(Main.wordGenre)
		{
			case 0:
				Q = Q01.basic;
				break;
			case 1:
				Q = Q01.system;
				break;
			case 2:
				Q = Q01.musicTitle;
				break;
			case 3:
				Q = Q01.karuto;
			default:
				break;
		}
		for ( int i = 0 ; i < Q.length ; i++ )
		{
			String[] s;
			int r = (int)(Math.random() * Q.length);
			s = Q[i];
			Q[i] = Q[r];
			Q[r] = s;
		} 
		 
	}
	
	public void setQ()
	{
		if ( Q[QCounter].length == 2 )		japa = Q[QCounter][1];
		else 								japa = Q[QCounter][0];

		rome = Main.jrt.translate(Q[QCounter][0]); 
	}
	
	public void draw(Graphics ogr,TextWindowA tw)
	{
		fontHeight = getFontHeight(ogr,font);
	
		ogr.setFont(font);
		ogr.setColor(Color.white);
		
		Place.setSize(tw.width,tw.height);
		Place.setPoint(tw.pointX,tw.pointY);
		Place.setCenterY( -(fontHeight/2) - ogr.getFontMetrics(font).getDescent() );
		Place.setCenterX( (japa.length() * fontSize) / 2 );
		
		for ( int i = 0 ; i < japa.length() ; i++ )
		{
			ogr.drawString(japa.substring(i,i+1),
				(((fontSize)-(getStringWidth(ogr,font,japa.substring(i,i+1)))))/2 +
				Place.xAlign(1,2) + (fontSize * i),Place.yAlign(2,7));	
		}
		
		ogr.setColor(Color.yellow);
		
		Place.setCenterX( ((rome.length() * (halfFontSize) / 2)
							- ( ((rome.substring(0,mojiCounter).length() ) * halfFontSize ) ) ));
		
		String str = rome.substring(mojiCounter,rome.length());
		for ( int i = 0 ; i < str.length() ; i++ )
		{
			
			ogr.drawString(str.substring(i,i+1),
				(halfFontSize -(getStringWidth(ogr,font,str.substring(i,i+1))))/2 +
				Place.xAlign(1,2) + (halfFontSize * i),Place.yAlign(5,7) );	
		}
	}
	

}
	