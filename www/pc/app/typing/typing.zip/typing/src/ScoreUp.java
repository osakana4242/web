import java.awt.*;

public class ScoreUp implements Runnable
{
	Thread myThread;
	
	int score = 0;
	int value = 0;
	int plusPoint = 0;
	int sleepTime = 10;
	
	public ScoreUp()
	{
	}
	
	public int getScore(){
		return value;
	}
	public void start()
	{
		if ( myThread == null )
		{
			myThread = new Thread(this);
			myThread.start();
		}
	}
	
	public void run()
	{
		Thread thisThread = Thread.currentThread();
		while ( myThread == thisThread )
		{
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException e)
			{
				break;
			}
				if(     10      > score - value) plusPoint = 1; 
				else if(100     > score - value) plusPoint = 4;
				else if(1000    > score - value) plusPoint = 32;
				else if(10000   > score - value) plusPoint = 128;
				else if(100000  > score - value) plusPoint = 1024;
				else if(1000000 > score - value) plusPoint = 4096;
				if(value < score) value += plusPoint;
				else stop();
		}
	}
	
	public void stop()
	{
		myThread = null;
	}
}