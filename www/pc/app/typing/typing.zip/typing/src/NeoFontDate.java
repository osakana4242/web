import java.awt.*;

public class NeoFontDate
{
	public int getFontHeight(Graphics g,Font font)
	{
		return g.getFontMetrics(font).getAscent() -
				g.getFontMetrics(font).getDescent() +
				g.getFontMetrics(font).getLeading();
	}
	public int getStringWidth(Graphics g,Font font,String s)
	{
		return g.getFontMetrics(font).stringWidth(s);
	}
}