import java.awt.*;
import java.awt.image.*;

public class Menu
{
	TextWindowA tw;
	
	int style = 0;
	int menuNum = 0;
	int optionNum = 0;
	
	Font font = Date.mFont;
	int fontHeight;
	final int fontSize = Date.mFontSize;
	final int halfFontSize = (fontSize / 2) + 4;
	
	final String[][] txt = new String[][]
		{
		{"�Q�[�����n�߂�","�l�b�g���[�N�ڑ�","���[�}���\�L�̕ύX","�e��ݒ�" },
		{"�G�̋���","�W������","�߂�"},
		{"�ƂĂ��Ăʂ邢","�Ăʂ邢","�܂��܂�","�Ђǂ�","�ƂĂ��Ђǂ�","���������ނ�"},
		{"�R�N�Q�g�W���p��","�p�\�R���p��","�~���[�W�b�N�^�C�g��","�J���g"}
		};
			 
	public Menu()
	{
	}
	public Menu(Graphics ogr)
	{
		fontHeight = ogr.getFontMetrics(font).getAscent();
		fontHeight -= ogr.getFontMetrics(font).getDescent();
		fontHeight += ogr.getFontMetrics(font).getLeading();
		
		tw = new TextWindowA((int)(Date.appWidth * 0.8),
							(int)(Date.appHeight * 0.4));
		
		tw.setPoint((Date.appWidth/2)*1,
					(Date.appHeight/6)*4);
		
		TextWindowA.setColor(Date.windowColor);
		
	}
	
	public void setPoint(int x,int y)
	{
		tw.setPoint(x,y);
	}
	
	
	public void draw(Graphics ogr)
	{
		ogr.setFont(font);
		
		tw.draw(ogr);
		
		
		Place.setSize(tw.width,tw.height);
		Place.setPoint(tw.pointX,tw.pointY);
		Place.setCenterY( fontHeight/2 );
		Place.setCenterX( (tw.width-6)/2 );
		
		ogr.setColor(Date.berColor);
		ogr.fillRect(Place.xAlign(1,2),Place.yAlign(menuNum+1,txt[style].length+1),
													tw.width-6,(int)(fontHeight*1.5));
		
		Place.setCenterY( -(fontHeight/2) - ogr.getFontMetrics(font).getDescent() );
		
		ogr.setColor(Color.white);
		
		switch(style)
		{
			case 0:
				for ( int i = 0 ; i < txt[style].length ; i++ )
				{
					drawString(ogr,txt[style][i],	1,2,	1+i,txt[style].length+1);
				}
				break;
			
			case 1:
				for ( int i = 0 ; i < txt[style].length ; i++ )
				{
					drawString(ogr,txt[style][i],	1,5,	1+i,txt[style].length+1);
				}
				drawString(ogr,txt[2][Main.enemyLevel],8,11,1,txt[style].length+1);
				drawString(ogr,txt[3][Main.wordGenre],8,11,2,txt[style].length+1);
				break;
			
			default:
				break;
		}
		
	}
	public void drawString(Graphics ogr,String s,int x1,int x2,int y1,int y2)
	{
		
		FontMetrics fm = ogr.getFontMetrics(ogr.getFont());
		
		Place.setCenterX( (s.length() * fm.getHeight()) / 2 );
		
		for ( int i = 0 ; i < s.length() ; i++ )
		{
			ogr.drawString(s.substring(i,i+1),
				(((fm.getHeight())-(fm.stringWidth(s.substring(i,i+1)))))/2 +
				Place.xAlign(x1,x2) + (fm.getHeight() * i),Place.yAlign(y1,y2));	
		}
	}
	
	public void clear()
	{
		tw = null;
		font = null;
	}
	

}
	