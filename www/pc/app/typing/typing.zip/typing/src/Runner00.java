import java.awt.*;
import java.awt.image.*;

public class Runner00
{
	Runner01 r01;
	static Image[][] myImage;
	
	public Runner00()
	{
		r01 = new Runner01();
	}
	
	public void setPoint(int pointX,int pointY)
	{
		r01.setPoint(pointX,pointY);
		r01.afterX = pointX;
		r01.afterY = pointY;
	}
	public void setMoveSpeed(int speed)
	{
		r01.speed = speed;
	}
	public void startMove(int afterX,int afterY)
	{
		r01.start(afterX,afterY);
	}
	
	public int getX() {
		return (int)r01.pointX;
	}
	
	public int getY() {
		return (int)r01.pointY;
	}
	
	public int getAfterX() {
		return r01.afterX;
	}
	
	public int getAfterY() {
		return r01.afterY;
	}
	
	public void stopMove() {
		r01.stop();
	}
	
	public void setAnimationSpeed(int speed)
	{
		r01.r02.speed = speed;
	}
	public void startAnimation()
	{
		r01.r02.start();
	}
	public void stopAnimation()
	{
		r01.r02.stop();
	}
	
	public void allStop()
	{
		stopMove();
		stopAnimation();
	}
	
	public void walkMode() {
		r01.r02.walkMode();
	}
	
	public void runMode() {
		r01.r02.runMode();
	}
	
	public void downMode() {
		r01.r02.downMode();
	}
	
	
	public void draw(Graphics grf,ImageObserver o)
	{
		r01.draw(grf,o);
	}
}