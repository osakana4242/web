import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class MenuKey extends Menu
{

	public MenuKey(Graphics ogr)
	{
		super(ogr);
	}
	
	public int up(int n,int max)
	{
		if(n < max)	return ++n;
		else		return n = 0;
		
	}
	
	public int down(int n,int max)
	{
		if(n > 0)	return --n;
		else		return max;
	}
	
	public void judge(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			//������������
			case KeyEvent.VK_UP :
				Date.sound[2].play();
				menuNum = down(menuNum,txt[style].length-1);
				break;
			//������������
			case KeyEvent.VK_DOWN:
				Date.sound[2].play();
				menuNum = up(menuNum,txt[style].length-1);
				break;
			
			//������������
			case KeyEvent.VK_LEFT:
				switch(style)
				{
					case 0:
						break;
					case 1:
						Date.sound[2].play();
						switch(menuNum)
						{
							case 0:
								Main.enemyLevel = down(Main.enemyLevel,txt[2].length-1);
								break;
							case 1:
								Main.wordGenre = down(Main.wordGenre,txt[3].length-1);
								break;
							default:
								break;
						}
						break;
					default:
						break;
				}
				
				break;
			
			//������������
			case KeyEvent.VK_RIGHT:
				switch(style)
				{
					case 0:
						break;
					case 1:
						Date.sound[2].play();
						switch(menuNum)
						{
							case 0:
								Main.enemyLevel = up(Main.enemyLevel,txt[2].length-1);
								break;
							case 1:
								Main.wordGenre = up(Main.wordGenre,txt[3].length-1);
								break;
							default:
								break;
						}
						break;
					default:
						break;
				}
				break;
			
			//�X�y�[�X���G���^�[����������
			case KeyEvent.VK_SPACE:
			case KeyEvent.VK_ENTER:
				switch(style)
				{
					case 0:
						switch(menuNum)
						{
							//�Q�[���J�n
							case 0:
								Date.sound[0].play();
								Main.style = 2;
								break;
							//�l�b�g���[�N�ڑ�
							case 1:
								break;
							//���[�}���\�L�̕ύX
							case 2:
								Date.sound[2].play();
								Main.style = 3;
								break;
							//�e��ݒ�
							case 3:
								Date.sound[2].play();
								style = 1;
								menuNum = 0;
							default:
								break;
						}
					//�e��ݒ�
					case 1:
						switch(menuNum)
						{
							case 0:
								break;
							
							case 1:
								break;
							
							case 2:
								Date.sound[2].play();
								style = 0;
								menuNum = 0;
								break;
						}
				break;
				}
			//���̑��̃L�[����������
			default:
				break;	
		}
	}
	public void clear()
	{
		super.clear();
	}

}