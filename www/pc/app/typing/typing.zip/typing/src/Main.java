import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends Applet implements Runnable {
	Thread mainThread;
	int sleepTime;

	MenuKey menu;
	Typing typ;
	AlterationKey alt;
	static int style = 1;
	static int enemyLevel = 0;
	static int wordGenre = 3;

	static JRtranslate jrt = new JRtranslate();

	Image offs;
	Graphics ogr;

	public void init() {
		offs = createImage(500, 400);
		ogr = offs.getGraphics();
		setMenu();
		for (int i = 0; i < Date.auc01.length; i++) {
			Date.sound[i] = getAudioClip(getDocumentBase(), Date.auc01[i]
					+ ".au");
		}

		addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
			}

			public void keyPressed(KeyEvent e) {
				switch (style) {
				case 0:
					break;
				case 1:
					menu.judge(e);
					break;
				case 2:
					typ.key(e);
					break;
				case 3:
					alt.judge(e);
				default:
					break;
				}
			}
		});
		requestFocus();
	}

	public void setMenu() {
		menu = new MenuKey(ogr);

	}

	public void setAlteration() {
		alt = new AlterationKey(ogr);
	}

	public void setGameStart() {

		Runner00.myImage = new Image[Date.img.length][];
		for (int i = 0; i < Date.img.length; i++) {
			Runner00.myImage[i] = new Image[Date.img[i].length];
			for (int j = 0; j < Date.img[i].length; j++) {
				Runner00.myImage[i][j] = getImage(getDocumentBase(),
						Date.img[i][j] + ".gif");
			}
		}

		typ = new Typing(ogr);

		typ.myImage = new Image[Date.countImg.length][];
		for (int i = 0; i < Date.countImg.length; i++) {
			typ.myImage[i] = new Image[Date.countImg[i].length];
			for (int j = 0; j < Date.countImg[i].length; j++) {
				typ.myImage[i][j] = getImage(getDocumentBase(),
						Date.countImg[i][j] + ".gif");
			}
		}

		typ.background = new Image[Date.background.length];
		for (int i = 0; i < Date.background.length; i++) {
			typ.background[i] = getImage(getDocumentBase(), Date.background[i]
					+ ".jpg");
		}
	}

	public void main() {
	}

	// ******** �`�� ********************************
	public void update(Graphics g) {
		switch (style) {
		// ���j���[
		case 1:
			menu.draw(ogr);
			break;

		// �Q�[����
		case 2:
			typ.draw(ogr, this);
			break;
		// ���[�}���\�L�̕ύX
		case 3:
			alt.draw(ogr);
			break;
		default:
			break;
		}

		g.drawImage(offs, 0, 0, this);
	}

	public void paint(Graphics g) {
	}

	public void start() {
		if (mainThread == null) {
			mainThread = new Thread(this);
			mainThread.start();
		}
	}

	public void run() {
		Thread thisThread = Thread.currentThread();
		while (mainThread == thisThread) {
			try {
				final int sleepTime = 1000 / 60;
				Thread.sleep(sleepTime);
			} catch (InterruptedException e) {
				break;
			}
			switch (style) {
			// ���j���[
			case 1:
				if (menu == null) {
					clear();
					setMenu();
				}
				break;

			// �Q�[����
			case 2:
				if (typ == null) {
					clear();
					setGameStart();
				}
				break;

			// ���[�}�����͂̕ύX
			case 3:
				if (alt == null) {
					clear();
					setAlteration();
				}
				break;

			default:
				break;
			}
			// main() ;
			repaint();
		}
	}

	public void stop() {
		clear();
		mainThread = null;
	}

	public void clear() {

		if (menu != null)
			menu = null;

		if (typ != null) {
			typ.allStop();
			typ = null;
		}

		if (alt != null)
			alt = null;
	}
}
