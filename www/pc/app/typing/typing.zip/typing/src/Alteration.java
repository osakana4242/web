import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Alteration extends NeoFontDate
{
	int style = 0;
	
	int numX = 0;
	int numY = 0;
	static final int[][] change = new int[][] 
			{
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0,0,0,0,0},
				{0},
				{0,0,0,0}
			};  
	
	final String[][][] changeWord = new String[][][]
		{
			{{"��","LA","XA"},{"��","LI","XI"},{"��","LU","XU"},{"��","LE","XE"},{"��","LO","XO"}},
			{{"����","SYA","SHA"},{"��","SI","SHI"},{"����","SYU","SHU"},{"����","SYE","SHE"},{"����","SYO","SHO"}},
			{{"����","ZYA","JA","JYA"},{"��","ZI","JI"},{"����","ZYU","JU","JYU"},{"����","ZYE","JE","JYE"},{"����","ZYO","JO","JYO"}},
			{{"����","TYA","CYA","CHA"},{"��","TI","CHI"},{"����","TYU","CYU","CHU"},{"����","TYE","CYE","CHE"},{"����","TYO","CYO","CHO"}},
			{{"��","HU","FU"}},
			{{"��","LYA","XYA"},{"��","LYU","XYU"},{"��","LYO","XYO"},{"��","LTU","XTU"}},
			{{"���Z�b�g"},{"�߂�"}}
		};
		
	TextWindowA tw;
	Font font = Date.mFont;
	int fontHeight;
	final int fontSize = Date.mFontSize;
	final int halfFontSize = (fontSize / 2) + 4;
	
	
	
	public Alteration(Graphics ogr)
	{
		fontHeight = ogr.getFontMetrics(font).getAscent();
		fontHeight -= ogr.getFontMetrics(font).getDescent();
		fontHeight += ogr.getFontMetrics(font).getLeading();
		
		Place.setSize(Date.appWidth,Date.appHeight);
		Place.setPoint(0,0);
		tw = new TextWindowA((int)(Date.appWidth * 0.8),(int)(Date.appHeight * 0.8));
		Place.setCenterX(0);
		Place.setCenterY(0);
		
		tw.setPoint(Place.xAlign(1,2),Place.yAlign(1,2));
		TextWindowA.setColor(Date.windowColor);
	
	}
	
	public void draw(Graphics ogr)
	{
		ogr.setColor(Color.black);
		ogr.fillRect(0,0,Date.appWidth,Date.appHeight);
		
		tw.draw(ogr);
		
		Place.setSize(tw.width,tw.height);
		Place.setPoint(tw.pointX,tw.pointY);
		
		TextWindowA stw = new TextWindowA(fontHeight*3,fontHeight*3);
		
		Place.setCenterY(0);
		Place.setCenterX(0);
		
		ogr.setColor(Date.berColor);
		ogr.fillRect(Place.xAlign(numX+1,6)-stw.width,Place.yAlign(numY+1,8)-stw.height,stw.width,stw.height);
		
		ogr.setColor(Color.white);
		ogr.setFont(Date.sFont);
		for(int i = 0 ; i < changeWord.length ; i++)
		{
			for(int j = 0 ; j < changeWord[i].length ; j++)
			{
				Place.setSize(tw.width,tw.height);
				Place.setPoint(tw.pointX,tw.pointY);
				Place.setCenterX( stw.width  / 2 );
				Place.setCenterY( stw.height / 2 );
				stw.setPoint(Place.xAlign(j+1,6),Place.yAlign(i+1,8));
				
				Place.setSize(stw.width,stw.height);
				Place.setPoint(stw.pointX,stw.pointY);
				Place.setCenterY( -(getFontHeight(ogr,Date.sFont)/2) );
				
				String s = changeWord[i][j][0];
				if( changeWord[i][j].length == 1 ) drawString(ogr,s,1,2,1,2);
				else {	
					drawString(ogr,s,1,2,1,5);
					s = changeWord[i][j][change[i][j]+1];
					drawString(ogr,s,1,2,4,5);
				}
			}
		}
	}
	
	public void drawString(Graphics ogr,String s,int x1,int x2,int y1,int y2)
	{
		
		FontMetrics fm = ogr.getFontMetrics(ogr.getFont());
		
		Place.setCenterX( (s.length() * fm.getHeight()) / 2 );
		
		for ( int i = 0 ; i < s.length() ; i++ )
		{
			ogr.drawString(s.substring(i,i+1),
				(((fm.getHeight())-(fm.stringWidth(s.substring(i,i+1)))))/2 +
				Place.xAlign(x1,x2) + (fm.getHeight() * i),Place.yAlign(y1,y2));	
		}
	}
	
	public void allStop()
	{
	}
}

	