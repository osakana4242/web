import java.awt.*;
import java.awt.image.*;

public class TextWindowA
{
	int pointX = 0; 
	int pointY = 0;
	int width  = 0;
	int height = 0;
	static Color col = new Color(0,0,0); 
	
	public TextWindowA(int x,int y,int w,int h)
	{
		pointX = x;
		pointY = y;
		width  = w;
		height = h;
	}
	public TextWindowA(int w,int h)
	{
		width  = w;
		height = h;
	}

	public void setPoint(int x,int y)
	{
		pointX = x - (width/2);
		pointY = y - (height/2);
	}
	
	public static void setColor(Color col)
	{
		TextWindowA.col = col;
	}
	
	public static void setColor(int r,int g,int b)
	{
		TextWindowA.col = new Color(r,g,b);
	}
	public void draw(Graphics grf)
	{
		Place.setSize(Date.appWidth,Date.appHeight);
		Place.setPoint(0,0);
		Place.setCenterX( width  / 2 );
		Place.setCenterY( height / 2 );
		
		grf.setColor(TextWindowA.col);
		grf.fillRect(pointX,pointY,width,height);
		grf.setColor(Color.white);
		grf.drawRect(pointX + 1,pointY + 1,width-3,height-3);
	}	
}
	