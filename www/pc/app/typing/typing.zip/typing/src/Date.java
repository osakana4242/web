import java.awt.*;
import java.applet.*;

public class Date
{
	static int appWidth = 500;
	static int appHeight = 400;
	static int walkWidth = 32;
	static int walkHeight = 48;
	static int title01Width = 458;
	static int title01Height = 57;
	static int countSize = 96;
	static int startWidth = 240;
	static int startHeight = 60;
	static int winWidth = 360;
	static int winHeight = 60;
	static int loseWidth = 360;
	static int loseHeight = 60;
	
	static Color windowColor = new Color(128,128,255);
	static Color berColor = new Color(0,0,192);
	
	static int sFontSize = 14;
	static Font sFont = new Font("�l�r �S�V�b�N",Font.BOLD,sFontSize);
	static int mFontSize = 18;
	static Font mFont = new Font("�l�r �S�V�b�N",Font.BOLD,mFontSize);
	static int lFontSize = 30;
	static Font lFont = new Font("�l�r �S�V�b�N",Font.PLAIN,lFontSize);
	static int xlFontSize = 100;
	static Font xlFont = new Font("�l�r �S�V�b�N",Font.PLAIN,xlFontSize); 
	
	static String[][] img = new String[][]
		{
		{"walk01","walk02","walk03","walk04"},
		{"run01","run02","run03","run04"},
		{"down01","down02","down03"}
		};
		
	static String[][] countImg = new String[][]
		{
		{"count1","count2","count3","count4","count5"},
		{"start"},
		{"win"},
		{"lose"}
		};
	static String[] background = new String[]
		{"bg01"}; 
		
	
	static String[] auc01 = new String[]
		{"start","type","select","high","down"};
		
	static AudioClip[] sound = new AudioClip[auc01.length];
}