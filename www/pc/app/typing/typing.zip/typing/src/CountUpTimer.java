import java.awt.*;
import java.awt.image.*;

public class CountUpTimer implements Runnable
{
	Thread myThread;
	TextWindowA tw;
	
	final int sleepTime = 10;
	
	int[] s = new int[4];//second �b
	int[] m = new int[2];//minute ��
	
	Font font = Date.sFont;
	int fontSize = Date.sFontSize;
	int fontWidth = fontSize;
	
	
	//�R���X�g���N�^
	public CountUpTimer(int pointX,int pointY)
	{
		reset();
		
		tw = new TextWindowA(fontSize*9,fontSize + 10);
		
		setPoint(pointX,pointY);
		
	}
	
	//�^�C�}�[�\���g�̉�����Ԃ�
	public int getWidth() {
		return tw.width;
	}
	
	//�^�C�}�[�\���g�̍�����Ԃ�
	public int getHeight() {
		return tw.height;
	}
	//���v��\�����鎞�̈ʒu��ݒ�
	public void setPoint(int pointX,int pointY)
	{
		tw.setPoint(pointX,pointY);
	}
	
	//�o�ߎ��Ԃ�0�ɂ���B
	public void reset()
	{
		for(int i = 0 ; i < s.length ; i++)
		{
			s[i] = 0;
		}
		for(int i = 0 ; i < m.length ; i++)
		{
			m[i] = 0;
		}
	}
	
	//�J�E���g�̊J�n
	public void start()
	{
		if ( myThread == null )
		{
			myThread = new Thread(this);
			myThread.start();
		}
	}
	
	public void run()
	{
		Thread thisThread = Thread.currentThread();
		while ( myThread == thisThread )
		{
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException e)
			{
				break;
			}
			
			s[0]++;
			for ( int i = 0 ; i < s.length ; i++ )
			{
				if ( s[i] == 10 )
				{
					s[i] = 0;
					s[i+1]++;
				}
				else break;
			}
			
			if ( s[3] == 6 )
			{
				s[3] = 0;
				m[0]++;
				if ( m[0] == 10 )
				{
					m[0] = 0;
					m[1]++;
					if ( m[1] == 10 )
					{
						m[1] = 0;
					}
				}
			} 
			
		}
	}
	
	//�J�E���g���ꎞ��~
	public void stop()
	{
		myThread = null;
	}
	
	public void draw(Graphics ogr)
	{
		
		tw.draw(ogr);
		
		Place.setSize(tw.width,tw.height);
		Place.setPoint(tw.pointX,tw.pointY);
		Place.setCenterY( -(fontSize / 2 ) );
		Place.setCenterX( (fontWidth * 8) / 2 );
		
		ogr.setFont(font);
		ogr.setColor(Color.white);
		equalsWidth(ogr,String.valueOf(m[1]),0);
		equalsWidth(ogr,String.valueOf(m[0]),1);
		equalsWidth2(ogr,":",				 2);
		equalsWidth(ogr,String.valueOf(s[3]),3);
		equalsWidth(ogr,String.valueOf(s[2]),4);
		equalsWidth2(ogr,":",				 5);
		equalsWidth(ogr,String.valueOf(s[1]),6);
		equalsWidth(ogr,String.valueOf(s[0]),7);
		
	}
	public void equalsWidth(Graphics ogr,String str,int num)
	{
		
		ogr.drawString(str,
			(fontWidth -(ogr.getFontMetrics(font).stringWidth(str)))/2 +
				Place.xAlign(1,2) + (fontWidth * num),
			(Place.yAlign(1,2) ) ); 
		
	}
	public void equalsWidth2(Graphics ogr,String str,int num)
	{
		
		ogr.drawString(str,
			(fontWidth -(ogr.getFontMetrics(font).stringWidth(str)))/2 +
				Place.xAlign(1,2) + (fontWidth * num),
			(Place.yAlign(1,2) - ogr.getFontMetrics(font).getDescent() )); 
		
	}
}