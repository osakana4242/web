import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class AlterationKey extends Alteration
{

	public AlterationKey(Graphics ogr)
	{
		super(ogr);
	}
	
	public int up(int n,int max)
	{
		if(n < max)	return ++n;
		else		return n = 0;
		
	}
	
	public int down(int n,int max)
	{
		if(n > 0)	return --n;
		else		return max;
	}
	
	public void judge(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			//������������
			case KeyEvent.VK_UP :
				Date.sound[2].play();
				do
				{
					numY = down(numY,changeWord.length-1);
				}while(numX > changeWord[numY].length-1);				
				break;
			//������������
			case KeyEvent.VK_DOWN:
				Date.sound[2].play();
				do
				{
					numY = up(numY,changeWord.length-1);
				}while(numX > changeWord[numY].length-1);
				break;				
			
			//������������
			case KeyEvent.VK_LEFT:
				Date.sound[2].play();
				numX = down(numX,changeWord[numY].length-1);
				break;
			//������������
			case KeyEvent.VK_RIGHT:
				Date.sound[2].play();
				numX = up(numX,changeWord[numY].length-1);
				break;
			
			//�X�y�[�X���G���^�[����������
			case KeyEvent.VK_SPACE:
			case KeyEvent.VK_ENTER:
				Date.sound[2].play();
				switch(numY)
				{
					case 6:
						switch(numX)
						{
							case 0:
								
								for(int i = 0 ; i < change.length ; i++) {
									for(int j = 0 ; j < change[i].length ; j++) {
										change[i][j] = 0;
									}
								}
								break;
							case 1:
								escape();
								break;
							default:
								break;
						}
						break;
					default:
						change[numY][numX] = up(change[numY][numX],changeWord[numY][numX].length-2);
						break;
				}
				break;
			case KeyEvent.VK_ESCAPE:
				escape();
				break;
			
			//���̑��̃L�[����������
			default:
				break;	
		}
	}
	
	public void escape()
	{
		Main.jrt.setLA(changeWord[0][0][change[0][0]+1]);
		Main.jrt.setLI(changeWord[0][1][change[0][1]+1]);
		Main.jrt.setLU(changeWord[0][2][change[0][2]+1]);
		Main.jrt.setLE(changeWord[0][3][change[0][3]+1]);
		Main.jrt.setLO(changeWord[0][4][change[0][4]+1]);
		
		Main.jrt.setSYA(changeWord[1][0][change[1][0]+1]);
		Main.jrt.setSI(changeWord[1][1][change[1][1]+1]);
		Main.jrt.setSYU(changeWord[1][2][change[1][2]+1]);
		Main.jrt.setSYE(changeWord[1][3][change[1][3]+1]);
		Main.jrt.setSYO(changeWord[1][4][change[1][4]+1]);
		
		Main.jrt.setZYA(changeWord[2][0][change[2][0]+1]);
		Main.jrt.setZI(changeWord[2][1][change[2][1]+1]);
		Main.jrt.setZYU(changeWord[2][2][change[2][2]+1]);
		Main.jrt.setZYE(changeWord[2][3][change[2][3]+1]);
		Main.jrt.setZYO(changeWord[2][4][change[2][4]+1]);
		
		Main.jrt.setTYA(changeWord[3][0][change[3][0]+1]);
		Main.jrt.setTI(changeWord[3][1][change[3][1]+1]);
		Main.jrt.setTYU(changeWord[3][2][change[3][2]+1]);
		Main.jrt.setTYE(changeWord[3][3][change[3][3]+1]);
		Main.jrt.setTYO(changeWord[3][4][change[3][4]+1]);
		
		Main.jrt.setHU(changeWord[4][0][change[4][0]+1]);
		
		Main.jrt.setLYA(changeWord[5][0][change[5][0]+1]);
		Main.jrt.setLYU(changeWord[5][1][change[5][1]+1]);
		Main.jrt.setLYO(changeWord[5][2][change[5][2]+1]);
		Main.jrt.setLTU(changeWord[5][3][change[5][3]+1]);
		Main.style = 1;
	}

}